/*
 * keypad.h
 *
 *  Created on: May 9, 2024
 *      Author: jorda
 */

#ifndef KEYPAD_H_
#define KEYPAD_H_

/* Function Prototypes */
void KEYPAD_Init(void);
char KEYPAD_ReadKey(void);

#endif /* KEYPAD_H_ */
